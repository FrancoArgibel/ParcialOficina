package Interfaces;

public interface iDescuento {
    public Double aplicarDescuento (int porcentaje);

}