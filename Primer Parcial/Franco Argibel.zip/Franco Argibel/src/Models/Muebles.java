package Models;

public class Muebles extends Productos{

    public Muebles(String name, double price, Integer stock) {
        super(name, price, stock);
    }
    
}