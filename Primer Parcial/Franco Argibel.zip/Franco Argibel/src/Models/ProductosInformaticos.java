package Models;

public class ProductosInformaticos extends Productos {

    public ProductosInformaticos(String name, double price, Integer stock) {
        super(name, price, stock);
    }
    
    
}
